"""
stats.py

Computes descriptive statistics (mean, median, mode, range, etc.)
for numeric columns in a weather dataset.
"""

import pandas as pd


def descriptive_stats(df: pd.DataFrame, column: str) -> dict:
    """
    Compute descriptive statistics for a numeric column in the DataFrame.

    Stats included:
    - count
    - mean
    - median
    - mode
    - min
    - max
    - range
    - standard deviation
    - variance

    Args:
        df: The weather dataset DataFrame.
        column: The name of the column to analyze.

    Returns:
        A dictionary containing the computed statistics.
    """
    series = pd.to_numeric(df[column], errors="coerce").dropna()

    if series.empty:
        return {"column": column, "error": "No valid numeric values found"}

    mode_vals = series.mode()
    mode = mode_vals.iloc[0] if not mode_vals.empty else None

    return {
        "column": column,
        "count": int(series.count()),
        "mean": float(series.mean()),
        "median": float(series.median()),
        "mode": float(mode) if mode is not None else None,
        "min": float(series.min()),
        "max": float(series.max()),
        "range": float(series.max() - series.min()),
        "std": float(series.std()),
        "var": float(series.var()),
    }
